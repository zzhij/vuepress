import "D:\\project\\app\\github\\vuepress\\node_modules\\@vuepress\\plugin-nprogress\\enhanceAppFile.js"
export default {}