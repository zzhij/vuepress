import Vue from 'vue'

Vue.component("CodeBlock", () => import("D:\\project\\app\\github\\vuepress\\node_modules\\@vuepress\\theme-default\\global-components\\CodeBlock"))
Vue.component("Badge", () => import("D:\\project\\app\\github\\vuepress\\node_modules\\@vuepress\\theme-default\\global-components\\Badge"))
Vue.component("CodeGroup", () => import("D:\\project\\app\\github\\vuepress\\node_modules\\@vuepress\\theme-default\\global-components\\CodeGroup"))


export default {}